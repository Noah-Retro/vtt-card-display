"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => VttCardDisplay
});
module.exports = __toCommonJS(main_exports);
var import_obsidian = require("obsidian");
var DEFAULT = {
  folderPath: "Cards",
  popoutLeft: 1920,
  popoutTop: 0,
  popoutWidth: 800,
  popoutHeight: 600
};
var VttCardDisplay = class extends import_obsidian.Plugin {
  constructor() {
    super(...arguments);
    this.cards = [];
    this.current = 0;
    this.popoutWindow = null;
  }
  async onload() {
    console.log("VTT Card Display loaded (TS)");
    this.settings = Object.assign({}, DEFAULT, await this.loadData());
    await this.loadCards();
    this.addCommand({ id: "vtt-open-popout", name: "Open Cards Popout", callback: () => this.openPopout() });
    this.addCommand({ id: "vtt-next-card", name: "Next Card", callback: () => this.nextCard() });
    this.addCommand({ id: "vtt-prev-card", name: "Previous Card", callback: () => this.prevCard() });
    this.addSettingTab(new VttCardDisplaySettingTab(this.app, this));
    window.addEventListener("message", (ev) => {
      if (!ev.data || ev.data.plugin !== "vtt-card-display")
        return;
      if (ev.data.type === "next")
        this.nextCard();
      if (ev.data.type === "prev")
        this.prevCard();
      if (ev.data.type === "requestCurrent")
        this.sendCurrentToPopout();
    });
  }
  onunload() {
    if (this.popoutWindow && !this.popoutWindow.closed)
      this.popoutWindow.close();
  }
  async loadCards() {
    const folder = (this.settings.folderPath || "").trim();
    const files = this.app.vault.getFiles();
    const exts = [".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg"];
    this.cards = files.filter((f) => folder === "" || f.path.startsWith(folder + "/")).filter((f) => exts.some((e) => f.name.toLowerCase().endsWith(e))).map((f) => this.app.vault.getResourcePath(f));
    this.current = 0;
    console.log("vtt-card loaded cards", this.cards.length);
  }
  openPopout() {
  }
  buildPopoutHtml() {
  }
  sendCurrentToPopout() {
  }
  nextCard() {
  }
  prevCard() {
  }
  // Project helper stubs (see JS implementation)
  async projectItemById(id) {
  }
  async projectCurrentFileAsRendered() {
  }
  async projectFirstImageInCurrentFile() {
  }
};
var VttCardDisplaySettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
  }
};
module.exports = (module.exports && module.exports.default) ? module.exports.default : module.exports;
//# sourceMappingURL=main.js.map
