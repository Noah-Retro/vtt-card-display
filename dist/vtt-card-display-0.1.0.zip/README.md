# VTT Card Display

Minimal Obsidian plugin to display game cards and pop them out to another window (useful for second monitor display).

Usage
- Put card images in a folder in your vault (default: `Cards`).
- Open the command palette and run `Open Cards Popout` to open the pop-out window.
- Use the `Next Card` and `Previous Card` commands or the arrow keys in the popout to navigate.

Projecting from notes
- You can register **items** (images, statblocks, or "note-first-image") in the plugin settings. Each item has an `id`, `title`, `type` and `value`.
- Use the command **Project registered item...** to pick and project an item.
- You can insert `[[project:ITEM_ID]]` in a note — it will be replaced by a button in preview that projects that registered item.
- Use **Project current file (rendered)** to render the current note (useful if you use `statblock` or `quickmonster` plugins that decorate the rendered HTML).
- Use **Project first image in current note** to project the first `![]()` image in the active note.
 - Use **Project current file (rendered)** to render the current note (the plugin will try to extract `statblock` or `quickmonster` elements if present and project only that block).
 - Use **Project first image in current note** to project the first `![]()` image in the active note.
 - Use **Open Card Viewer Pane** to open a right-side pane with thumbnails; click a thumb to project that card.
 - Use **Save popout position** while a popout is open to store its coordinates and size; use **Move popout to second monitor (approx)** to push the popout to the right of the primary screen.

Hotkeys
- Every registered item creates a command `Project: <title>` which you can bind a hotkey to from Obsidian’s Hotkeys settings. Also bind any other commands (Next/Prev, Open Card Viewer) for easy control.

Quick manual test checklist
- Add images `Cards/goblin.svg` and `Cards/dragon.svg` (already included in the vault's `Cards` folder).
- Open Settings -> Registered items and add an item pointing to `Cards/goblin.svg` (type: image).
- Use `Open Card Viewer Pane` and click a thumbnail to project it.
- Insert `[[project:item...]]` for the registered item in any note preview and click the button.
- Use `Project current file (rendered)` on a statblock note and verify the statblock is projected.

How to build & test locally
---------------------------
- cd into `.obsidian/plugins/vtt-card-display`
- Run `npm install` to install dev dependencies (`esbuild`, `typescript`, `archiver`)
- Run `npm run build` to compile `src/main.ts` into `main.js` (bundled)
- Run `npm test` to run a small verification script that checks the build and basic module exports
- Run `npm run package` to create `dist/<id>-<version>.zip` for distribution

Settings
- Configure `Cards folder path` and `Popout left,top,width,height` in the plugin settings.

Notes
- This is a minimal scaffold — you can extend it with thumbnails, drag/drop, and a docked viewer pane.
 - Debugging: plugin logs helpful information into the console; if a registered item fails to project you'll see a notification.
